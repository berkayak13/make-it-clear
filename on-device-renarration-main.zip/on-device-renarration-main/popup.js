// Popup script
document.addEventListener('DOMContentLoaded', async () => {
  const enableToggle = document.getElementById('enableToggle');
  const taskSelect = document.getElementById('taskSelect');
  const personaSelect = document.getElementById('personaSelect'); // dynamic personas
  const autoDetectToggle = document.getElementById('autoDetectToggle');
  const optionsBtn = document.getElementById('optionsBtn');
  const taskName = document.getElementById('taskName');
  const taskInfo = document.getElementById('taskInfo');
  const useWebLLMToggle = document.getElementById('useWebLLMToggle');
  const initModelBtn = document.getElementById('initModelBtn');
  const webllmStatus = document.getElementById('webllmStatus');
  const captureBtn = document.getElementById('capturePageBtn');
  const captureStatus = document.getElementById('captureStatus');
  const describeBtn = document.getElementById('describePageBtn');
  const describeStatus = document.getElementById('describeStatus');
  const personaName = document.getElementById('personaName');
  const personaPromptEl = document.getElementById('personaPrompt');
  const renarrateBtn = document.getElementById('renarratePageBtn');
  const renarrateStatus = document.getElementById('renarrateStatus');
  const testingDashboardBtn = document.getElementById('testingDashboardBtn');

  let currentTasks = {};
  let currentPersonas = {};

  // Load current settings
  const settings = await chrome.storage.sync.get([
    'enabled',
    'currentTask',
    'currentProfile',
    'autoDetect',
    'useWebLLM',
    'currentPersona',
    'personas',
    'tasks',
    'profiles'
  ]);

  let tasks = settings.tasks;
  let currentTask = settings.currentTask;
  let shouldWrite = false;
  if ((!tasks || !Object.keys(tasks).length) && settings.profiles && Object.keys(settings.profiles).length) {
    tasks = settings.profiles;
    shouldWrite = true;
  }
  if (!currentTask && settings.currentProfile) {
    currentTask = settings.currentProfile;
    shouldWrite = true;
  }
  if (!tasks || !Object.keys(tasks).length) {
    tasks = {};
  }
  if (!currentTask) {
    currentTask = Object.keys(tasks)[0] || 'simple';
  }
  if (shouldWrite) {
    await chrome.storage.sync.set({ tasks, currentTask });
  }

  currentTasks = tasks || {};
  currentPersonas = settings.personas || {};
  enableToggle.checked = settings.enabled !== false;
  taskSelect.value = currentTask || 'simple';
  // Populate personas dynamically
  populatePersonaOptions(currentPersonas, settings.currentPersona);
  if (autoDetectToggle) {
    autoDetectToggle.checked = settings.autoDetect !== false;
  }
  useWebLLMToggle.checked = settings.useWebLLM !== false;

  populateTaskOptions(currentTasks, currentTask || 'simple');
  updateTaskInfo(taskSelect.value);
  updatePersonaInfo(personaSelect.value);

  // Listen for runtime persona list changes (e.g., after editing in options)
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && (changes.personas || changes.currentPersona || changes.tasks || changes.currentTask || changes.profiles || changes.currentProfile)) {
      chrome.storage.sync.get(['personas','currentPersona','tasks','currentTask','profiles','currentProfile']).then(async ({ personas, currentPersona, tasks, currentTask, profiles, currentProfile }) => {
        let nextTasks = tasks;
        let nextTask = currentTask;
        let shouldWrite = false;
        if ((!nextTasks || !Object.keys(nextTasks).length) && profiles && Object.keys(profiles).length) {
          nextTasks = profiles;
          shouldWrite = true;
        }
        if (!nextTask && currentProfile) {
          nextTask = currentProfile;
          shouldWrite = true;
        }
        if (!nextTasks || !Object.keys(nextTasks).length) {
          nextTasks = {};
        }
        if (!nextTask) {
          nextTask = Object.keys(nextTasks)[0] || 'simple';
        }
        if (shouldWrite) {
          await chrome.storage.sync.set({ tasks: nextTasks, currentTask: nextTask });
        }
        if (nextTasks) {
          currentTasks = nextTasks;
          populateTaskOptions(currentTasks, nextTask || taskSelect.value || 'simple');
          updateTaskInfo(taskSelect.value);
        }
        if (personas) {
          currentPersonas = personas;
          populatePersonaOptions(currentPersonas, currentPersona);
          updatePersonaInfo(currentPersona);
        }
      });
    }
  });

  // Event listeners
  enableToggle.addEventListener('change', () => {
    chrome.storage.sync.set({ enabled: enableToggle.checked });
  });
  
  taskSelect.addEventListener('change', () => {
    const task = taskSelect.value;
    chrome.storage.sync.set({ currentTask: task });
    updateTaskInfo(task);
  });

  personaSelect.addEventListener('change', () => {
    const personaKey = personaSelect.value;
    chrome.storage.sync.set({ currentPersona: personaKey });
    updatePersonaInfo(personaKey);
  });
  
  if (autoDetectToggle) {
    autoDetectToggle.addEventListener('change', () => {
      chrome.storage.sync.set({ autoDetect: autoDetectToggle.checked });
    });
  }

  useWebLLMToggle.addEventListener('change', () => {
    chrome.storage.sync.set({ useWebLLM: useWebLLMToggle.checked });
  });

  initModelBtn.addEventListener('click', async () => {
    webllmStatus.textContent = 'Status: initializing...';
    try {
      const res = await chrome.runtime.sendMessage({ action: 'webllm-init' });
      if (res && res.success !== false) {
        webllmStatus.textContent = 'Status: ready';
      } else {
        webllmStatus.textContent = 'Status: failed (fallback active)';
      }
    } catch (e) {
      webllmStatus.textContent = 'Status: failed (see console)';
    }
  });

  // Capture full page screenshots
  if (captureBtn) {
    captureBtn.addEventListener('click', async () => {
      if (captureStatus) captureStatus.textContent = 'Capturing…';
      try {
        const res = await chrome.runtime.sendMessage({ action: 'capture-fullpage' });
        if (res && res.success) {
          if (captureStatus) captureStatus.textContent = `Captured ${res.count} slice(s)`;
        } else {
          if (captureStatus) captureStatus.textContent = res.error;
        }
      } catch (e) {
        if (captureStatus) captureStatus.textContent = 'Error during capture';
      }
    });
  }

  if (describeBtn) {
    describeBtn.addEventListener('click', async () => {
      if (describeStatus) describeStatus.textContent = 'Requesting…';
      try {
        const res = await chrome.runtime.sendMessage({ action: 'describe-page-screenshot' });
        if (res && res.success) {
          if (describeStatus) describeStatus.textContent = 'Done';
          await chrome.tabs.create({ url: chrome.runtime.getURL('viewers/describe-viewer.html') });
        } else {
          if (describeStatus) describeStatus.textContent = res?.error || 'Failed';
        }
      } catch (e) {
        if (describeStatus) describeStatus.textContent = 'Error';
      }
    });
  }

  if (renarrateBtn) {
    renarrateBtn.addEventListener('click', async () => {
      if (renarrateStatus) renarrateStatus.textContent = 'Processing…';
      try {
        const res = await chrome.runtime.sendMessage({ action: 'renarrate-page' });
        if (res && res.success) {
          if (renarrateStatus) renarrateStatus.textContent = 'Done';
          await chrome.tabs.create({ url: chrome.runtime.getURL('viewers/renarration-viewer.html') });
        } else {
          if (renarrateStatus) renarrateStatus.textContent = res?.error || 'Failed';
        }
      } catch (e) {
        if (renarrateStatus) renarrateStatus.textContent = 'Error';
      }
    });
  }

  if (testingDashboardBtn) {
    testingDashboardBtn.addEventListener('click', async () => {
      await chrome.tabs.create({ url: chrome.runtime.getURL('viewers/testing-dashboard.html') });
    });
  }

  // Optional: listen to progress events from offscreen init
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.__offscreenProgress) {
      const pct = Math.round((msg.progress || 0) * 100);
      webllmStatus.textContent = `Status: ${msg.stage} ${isFinite(pct) ? `(${pct}%)` : ''}`;
    }
  });
  
  optionsBtn.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
  
  function updateTaskInfo(task) {
    const p = currentTasks && currentTasks[task];
    if (p) {
      taskName.textContent = p.name || task;
      taskInfo.querySelector('.task-description').textContent = p.textPrompt || '';
    }
  }
  function updatePersonaInfo(key) {
    const p = currentPersonas && currentPersonas[key];
    if (p) {
      personaName.textContent = p.name || key;
      if (personaPromptEl) {
        personaPromptEl.textContent = p.systemAddendum || p.description || '';
      }
    }
  }

  function populatePersonaOptions(personas = {}, currentKey = 'general') {
    if (!personaSelect) return;
    personaSelect.innerHTML = '';
    const entries = Object.entries(personas || {});
    entries.forEach(([key, val]) => {
      const opt = document.createElement('option');
      opt.value = key;
      opt.textContent = val.name || key;
      personaSelect.appendChild(opt);
    });
    // Ensure current selection exists; fall back to first
    const effective = personas && personas[currentKey] ? currentKey : (entries[0]?.[0] || 'general');
    personaSelect.value = effective;
  }

  function populateTaskOptions(tasks = {}, currentKey = 'simple') {
    if (!taskSelect) return;
    taskSelect.innerHTML = '';
    const entries = Object.entries(tasks || {});
    entries.forEach(([key, val]) => {
      const opt = document.createElement('option');
      opt.value = key;
      opt.textContent = val.name || key;
      taskSelect.appendChild(opt);
    });
    const effective = tasks && tasks[currentKey] ? currentKey : (entries[0]?.[0] || 'simple');
    taskSelect.value = effective;
  }
});
