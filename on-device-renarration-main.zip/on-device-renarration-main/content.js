// Content script - Injected into web pages
// Handles text selection and UI overlay

let isEnabled = false;
let currentTask = 'simple';
let renarrationOverlay = null;

// Initialize
init();

async function init() {
  // Get current settings
  const settings = await chrome.runtime.sendMessage({ action: 'get-settings' });
  isEnabled = settings.enabled;
  currentTask = settings.currentTask;
  
  if (isEnabled) {
    setupEventListeners();
    createOverlay();
  }
}

// Listen for settings changes
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (changes.enabled) {
    isEnabled = changes.enabled.newValue;
    if (isEnabled) {
      setupEventListeners();
      createOverlay();
    } else {
      removeEventListeners();
      removeOverlay();
    }
  }
  if (changes.currentTask) {
    currentTask = changes.currentTask.newValue;
  }
});

// Create floating overlay for renarration results
function createOverlay() {
  if (renarrationOverlay) return;
  
  renarrationOverlay = document.createElement('div');
  renarrationOverlay.id = 'renarration-overlay';
  renarrationOverlay.style.display = 'none';
  document.body.appendChild(renarrationOverlay);
}

function removeOverlay() {
  if (renarrationOverlay && renarrationOverlay.parentNode) {
    renarrationOverlay.parentNode.removeChild(renarrationOverlay);
    renarrationOverlay = null;
  }
}

function showOverlay(content, x, y) {
  if (!renarrationOverlay) return;
  
  renarrationOverlay.innerHTML = `
    <div class="renarration-content">
      <div class="renarration-header">
        <span class="renarration-title">Renarration</span>
        <button class="renarration-close" id="renarration-close-btn">×</button>
      </div>
      <div class="renarration-body">${content}</div>
    </div>
  `;
  
  renarrationOverlay.style.display = 'block';
  renarrationOverlay.style.left = `${x}px`;
  renarrationOverlay.style.top = `${y}px`;
  
  // Add close button listener
  const closeBtn = document.getElementById('renarration-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', hideOverlay);
  }
}

function hideOverlay() {
  if (renarrationOverlay) {
    renarrationOverlay.style.display = 'none';
  }
}

// Event listeners
let selectionHandler = null;

function setupEventListeners() {
  // Handle text selection
  selectionHandler = handleTextSelection;
  document.addEventListener('mouseup', selectionHandler);
  
}

function removeEventListeners() {
  if (selectionHandler) {
    document.removeEventListener('mouseup', selectionHandler);
  }
}

async function handleTextSelection(e) {
  if (!isEnabled) return;
  
  const selection = window.getSelection();
  const text = selection.toString().trim();
  
  // Only process if text is selected and it's not within our overlay
  if (text && text.length > 10 && !e.target.closest('#renarration-overlay')) {
    // Show a small indicator button near selection
    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    
    showRenarrationButton(rect.right + 5, rect.top, text);
  }
}

function showRenarrationButton(x, y, text) {
  // Remove existing button if any
  const existingBtn = document.getElementById('renarration-trigger-btn');
  if (existingBtn) {
    existingBtn.remove();
  }
  
  const button = document.createElement('button');
  button.id = 'renarration-trigger-btn';
  button.className = 'renarration-trigger';
  button.innerHTML = '🔄';
  button.title = 'Renarrate selected text';
  button.style.position = 'absolute';
  button.style.left = `${x + window.scrollX}px`;
  button.style.top = `${y + window.scrollY}px`;
  button.style.zIndex = '10000';
  
  button.addEventListener('click', (e) => {
    e.stopPropagation();
    processTextRenarration(text, x, y);
    button.remove();
  });
  
  document.body.appendChild(button);
  
  // Auto-remove after 3 seconds
  setTimeout(() => {
    if (button.parentNode) {
      button.remove();
    }
  }, 3000);
}

async function processTextRenarration(text, x, y) {
  showOverlay('<div class="renarration-loading">Processing text...</div>', x, y + 30);
  
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'renarrate-text',
      text: text,
      task: currentTask
    });
    
    if (response.success) {
      showOverlay(response.result, x, y + 30);
    } else {
      showOverlay(`<div class="renarration-error">Error: ${response.error}</div>`, x, y + 30);
    }
  } catch (error) {
    showOverlay(`<div class="renarration-error">Error: ${error.message}</div>`, x, y + 30);
  }
}
