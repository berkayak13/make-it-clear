// Options page script

// Default tasks
const DEFAULT_TASKS = {
  'simple': {
    name: 'Simple Language',
    textPrompt: 'Rewrite this text in simple, easy-to-understand language with short sentences:',
    isDefault: true
  },
  'detailed': {
    name: 'Detailed Explanation',
    textPrompt: 'Provide a detailed and comprehensive explanation of this text:',
    isDefault: true
  },
  'academic': {
    name: 'Academic Style',
    textPrompt: 'Rewrite this text in formal academic language:',
    isDefault: true
  },
  'summary': {
    name: 'Summary',
    textPrompt: 'Summarize this text in a brief, concise way:',
    isDefault: true
  }
};

// NEW: Default personas (mirror background.js)
const DEFAULT_PERSONAS = {
  'berat': {
    name: 'Berat (Neighborhood Barber)',
    description: 'Low computer literacy; prefers very plain Turkish/English explanations.',
    systemAddendum: 'Target audience persona: Berat is a neighborhood barber with limited computer experience. Use very plain language and avoid economic jargon.'
  },
  'student': {
    name: 'Undergrad Student',
    description: 'Understands basic academic concepts; wants clear but not oversimplified explanations.',
    systemAddendum: 'Target audience persona: An undergraduate student seeking clear educational explanations with light context.'
  },
  'researcher': {
    name: 'Academic Researcher',
    description: 'Prefers formal, precise, domain-rich terminology.',
    systemAddendum: 'Target audience persona: Academic researcher expecting formal tone with precise terminology.'
  },
  'general': {
    name: 'General Public',
    description: 'Average reader; keep it accessible and neutral.',
    systemAddendum: 'Target audience persona: General public; keep tone neutral and accessible.'
  }
};

const DEFAULT_REMOTE_VLM = {
  useRemoteVLM: false,
  remoteVLMModel: 'gemini-2.0-flash',
  remoteVLMEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
  remoteVLMApiKey: ''
};

let currentTasks = {};
let editingTaskKey = null;

// NEW persona state
let currentPersonas = {};
let editingPersonaKey = null;
let currentPersonaActive = 'general';
let remoteSettings = { ...DEFAULT_REMOTE_VLM };
let currentTaskActive = 'simple';
let systemPromptTemplate = '';
let boilerplateText = '';
let templateSaveTimer = null;

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  await loadSettings();
  setupEventListeners();

  // Initialize active selectors after DOM and settings are ready
  hydrateActiveSelectors();
  updateEffectiveSystemPrompt();
});

// Extend loadSettings to include personas
async function loadSettings() {
  const settings = await chrome.storage.sync.get([
    'tasks',
    'currentTask',
    'profiles',
    'currentProfile',
    'personas',
    'currentPersona',
    'systemPromptTemplate',
    'useRemoteVLM',
    'remoteVLMModel',
    'remoteVLMEndpoint'
  ]);
  const local = await chrome.storage.local.get(['remoteVLMApiKey']);
  boilerplateText = await fetch(chrome.runtime.getURL('src/prompts/system.md')).then(r => r.text()).catch(() => '');
  
  let tasks = settings.tasks;
  let currentTask = settings.currentTask;
  let shouldWrite = false;

  if ((!tasks || !Object.keys(tasks).length) && settings.profiles && Object.keys(settings.profiles).length) {
    tasks = settings.profiles;
    shouldWrite = true;
  }
  if (!currentTask && settings.currentProfile) {
    currentTask = settings.currentProfile;
    shouldWrite = true;
  }
  if (!tasks || !Object.keys(tasks).length) {
    tasks = DEFAULT_TASKS;
    shouldWrite = true;
  }
  if (!currentTask) {
    currentTask = Object.keys(tasks)[0] || 'simple';
    shouldWrite = true;
  }
  if (shouldWrite) {
    await chrome.storage.sync.set({ tasks, currentTask });
  }

  currentTasks = tasks;
  currentTaskActive = currentTask;
  currentPersonas = settings.personas || DEFAULT_PERSONAS;
  currentPersonaActive = settings.currentPersona || 'general';
  systemPromptTemplate = (settings.systemPromptTemplate || '').trim();
  if (!systemPromptTemplate) {
    systemPromptTemplate = buildDefaultTemplate(boilerplateText);
    await chrome.storage.sync.set({ systemPromptTemplate });
  }
  const templateEl = document.getElementById('systemPromptTemplate');
  if (templateEl) templateEl.value = systemPromptTemplate;
  
  remoteSettings = {
    useRemoteVLM: settings.useRemoteVLM ?? DEFAULT_REMOTE_VLM.useRemoteVLM,
    remoteVLMModel: settings.remoteVLMModel || DEFAULT_REMOTE_VLM.remoteVLMModel,
    remoteVLMEndpoint: settings.remoteVLMEndpoint || DEFAULT_REMOTE_VLM.remoteVLMEndpoint,
    remoteVLMApiKey: local.remoteVLMApiKey || ''
  };
  document.getElementById('useRemoteVLM').checked = remoteSettings.useRemoteVLM;
  document.getElementById('remoteVLMEndpoint').value = remoteSettings.remoteVLMEndpoint;
  document.getElementById('remoteVLMModel').value = remoteSettings.remoteVLMModel;
  document.getElementById('remoteVLMApiKey').value = remoteSettings.remoteVLMApiKey;
  // Active persona selection removed from options (selection handled in popup)

  renderTasks();
  renderPersonas();
  document.getElementById('effectiveSystemPrompt').value = buildEffectiveSystemPrompt(boilerplateText, systemPromptTemplate);
}

// Populate and sync the top-level active task/persona dropdowns
function hydrateActiveSelectors() {
  const taskSel = document.getElementById('currentTaskSelect');
  const personaSel = document.getElementById('currentPersonaSelect');
  if (taskSel) {
    taskSel.innerHTML = '';
    Object.entries(currentTasks || {}).forEach(([key, val]) => {
      const opt = document.createElement('option');
      opt.value = key;
      opt.textContent = val.name || key;
      taskSel.appendChild(opt);
    });
    taskSel.value = currentTaskActive;
  }
  if (personaSel) {
    personaSel.innerHTML = '';
    Object.entries(currentPersonas || {}).forEach(([key, val]) => {
      const opt = document.createElement('option');
      opt.value = key;
      opt.textContent = val.name || key;
      personaSel.appendChild(opt);
    });
    personaSel.value = currentPersonaActive;
  }
}

function buildDefaultTemplate(boilerplate) {
  const parts = [];
  const base = (boilerplate || '').trim();
  if (base) parts.push(base);
  parts.push('Task:\n{task}');
  parts.push('Persona:\n{persona}');
  return parts.join('\n\n');
}

function buildEffectiveSystemPrompt(boilerplate, templateText) {
  const task = currentTasks[currentTaskActive];
  const persona = currentPersonas[currentPersonaActive];
  if (!task) return '';
  const taskText = task.textPrompt || '';
  const personaText = persona ? (persona.systemAddendum || persona.description || '') : '';
  const template = (templateText || '').trim() || buildDefaultTemplate(boilerplate);
  return applyTemplate(template, taskText, personaText).trim();
}

function updateEffectiveSystemPrompt() {
  const ta = document.getElementById('effectiveSystemPrompt');
  if (!ta) return;
  const templateEl = document.getElementById('systemPromptTemplate');
  const templateText = templateEl ? templateEl.value : systemPromptTemplate;
  ta.value = buildEffectiveSystemPrompt(boilerplateText, templateText);
}

// Render tasks
function renderTasks() {
  const taskList = document.getElementById('taskList');
  taskList.innerHTML = '';
  
  Object.keys(currentTasks).forEach(key => {
    const task = currentTasks[key];
    const taskItem = document.createElement('div');
    taskItem.className = `task-item ${task.isDefault ? 'default' : ''}`;
    const taskName = escapeHtml(task.name || '');
    const taskText = escapeHtml(task.textPrompt || '');
    
    taskItem.innerHTML = `
      <div class="task-info">
        <h3>${taskName}</h3>
        <p class="task-prompt"><strong>Text:</strong> ${taskText}</p>
        ${task.isDefault ? '<span class="task-badge">Default</span>' : ''}
        ${key === currentTaskActive ? '<span class="task-badge" style="background:#48bb78;">Active</span>' : ''}
      </div>
      <div class="task-actions">
        <button class="icon-btn edit-btn" data-key="${key}" title="Edit">✏️</button>
        ${!task.isDefault ? `<button class="icon-btn delete-btn" data-key="${key}" title="Delete">🗑️</button>` : ''}
      </div>
    `;
    
    taskList.appendChild(taskItem);
  });
  
  // Add event listeners to edit and delete buttons
  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const key = e.target.dataset.key;
      openTaskModal(key);
    });
  });
  
  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const key = e.target.dataset.key;
      deleteTask(key);
    });
  });
}

// NEW: Render personas list
function renderPersonas() {
  const list = document.getElementById('personaList');
  list.innerHTML = '';
  Object.keys(currentPersonas).forEach(key => {
    const p = currentPersonas[key];
    const item = document.createElement('div');
    item.className = 'task-item'; // reuse styles
    const personaName = escapeHtml(p.name || '');
    const personaText = escapeHtml(p.systemAddendum || p.description || '');
    item.innerHTML = `
      <div class="task-info">
        <h3>${personaName}</h3>
        <p class="persona-prompt"><strong>Text:</strong> ${personaText}</p>
        ${key === currentPersonaActive ? '<span class="task-badge" style="background:#48bb78;">Active</span>' : ''}
      </div>
      <div class="task-actions">
        <button class="icon-btn persona-edit-btn" data-key="${key}" title="Edit">✏️</button>
        ${DEFAULT_PERSONAS[key] ? '' : `<button class="icon-btn persona-delete-btn" data-key="${key}" title="Delete">🗑️</button>`}
      </div>
    `;
    list.appendChild(item);
  });
  list.querySelectorAll('.persona-edit-btn').forEach(btn => {
    btn.addEventListener('click', e => openPersonaModal(e.target.dataset.key));
  });
  list.querySelectorAll('.persona-delete-btn').forEach(btn => {
    btn.addEventListener('click', e => deletePersona(e.target.dataset.key));
  });
}

function escapeHtml(value='') {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Setup event listeners
function setupEventListeners() {
  // General settings
  document.getElementById('useRemoteVLM').addEventListener('change', saveSettings);
  document.getElementById('remoteVLMEndpoint').addEventListener('input', saveSettings);
  document.getElementById('remoteVLMModel').addEventListener('input', saveSettings);
  document.getElementById('remoteVLMApiKey').addEventListener('input', saveSettings);
  
  // Add task button
  document.getElementById('addTaskBtn').addEventListener('click', () => {
    openTaskModal(null);
  });
  
  // Reset button
  document.getElementById('resetBtn').addEventListener('click', resetToDefaults);
  
  // Modal buttons
  document.getElementById('modalClose').addEventListener('click', closeTaskModal);
  document.getElementById('cancelTaskBtn').addEventListener('click', closeTaskModal);
  document.getElementById('saveTaskBtn').addEventListener('click', saveTask);
  
  // Close modal on outside click
  document.getElementById('taskModal').addEventListener('click', (e) => {
    if (e.target.id === 'taskModal') {
      closeTaskModal();
    }
  });

  // NEW persona events
  document.getElementById('addPersonaBtn').addEventListener('click', () => openPersonaModal(null));
  document.getElementById('personaModalClose').addEventListener('click', closePersonaModal);
  document.getElementById('cancelPersonaBtn').addEventListener('click', closePersonaModal);
  document.getElementById('savePersonaBtn').addEventListener('click', savePersona);
  document.getElementById('personaModal').addEventListener('click', (e) => {
    if (e.target.id === 'personaModal') closePersonaModal();
  });
  const templateEl = document.getElementById('systemPromptTemplate');
  if (templateEl) {
    templateEl.addEventListener('input', queueSystemPromptSave);
  }
  const restoreBtn = document.getElementById('restoreSystemPromptBtn');
  if (restoreBtn) {
    restoreBtn.addEventListener('click', restoreSystemPromptTemplate);
  }

  // Active task selector
  const taskSel = document.getElementById('currentTaskSelect');
  if (taskSel) {
    taskSel.addEventListener('change', async () => {
      const key = taskSel.value;
      currentTaskActive = key;
      await chrome.storage.sync.set({ currentTask: key });
      renderTasks();
      updateEffectiveSystemPrompt();
    });
  }

  // Active persona selector
  const personaSel = document.getElementById('currentPersonaSelect');
  if (personaSel) {
    personaSel.addEventListener('change', async () => {
      const key = personaSel.value;
      currentPersonaActive = key;
      await chrome.storage.sync.set({ currentPersona: key });
      renderPersonas();
      updateEffectiveSystemPrompt();
    });
  }
}

// Open task modal
function openTaskModal(taskKey) {
  editingTaskKey = taskKey;
  const modal = document.getElementById('taskModal');
  const modalTitle = document.getElementById('modalTitle');
  
  if (taskKey) {
    // Edit existing task
    const task = currentTasks[taskKey];
    modalTitle.textContent = 'Edit Task';
    document.getElementById('taskNameInput').value = task.name;
    document.getElementById('textPromptInput').value = task.textPrompt;
  } else {
    // Create new task
    modalTitle.textContent = 'Add Custom Task';
    document.getElementById('taskNameInput').value = '';
    document.getElementById('textPromptInput').value = '';
  }
  
  modal.style.display = 'flex';
}

// Close task modal
function closeTaskModal() {
  document.getElementById('taskModal').style.display = 'none';
  editingTaskKey = null;
}

// Open persona modal
function openPersonaModal(key) {
  editingPersonaKey = key;
  const modal = document.getElementById('personaModal');
  const title = document.getElementById('personaModalTitle');
  if (key) {
    const p = currentPersonas[key];
    title.textContent = 'Edit Persona';
    document.getElementById('personaNameInput').value = p.name;
    document.getElementById('personaAddendumInput').value = p.systemAddendum || p.description || '';
  } else {
    title.textContent = 'Add Persona';
    document.getElementById('personaNameInput').value = '';
    document.getElementById('personaAddendumInput').value = '';
  }
  modal.style.display = 'flex';
}

function closePersonaModal() {
  document.getElementById('personaModal').style.display = 'none';
  editingPersonaKey = null;
}

// Save task
async function saveTask() {
  const name = document.getElementById('taskNameInput').value.trim();
  const textPrompt = document.getElementById('textPromptInput').value.trim();
  if (!name || !textPrompt) {
    alert('Please fill in all fields');
    return;
  }
  
  const existingTask = editingTaskKey ? currentTasks[editingTaskKey] : null;
  const task = {
    name,
    textPrompt,
    isDefault: existingTask ? !!existingTask.isDefault : false
  };
  
  if (editingTaskKey) {
    // Update existing task
    currentTasks[editingTaskKey] = task;
  } else {
    // Create new task with unique key
    const key = name.toLowerCase().replace(/\s+/g, '-');
    currentTasks[key] = { ...task, isDefault: false };
  }
  
  await chrome.storage.sync.set({ tasks: currentTasks });
  renderTasks();
  hydrateActiveSelectors();
  updateEffectiveSystemPrompt();
  closeTaskModal();
  showSaveStatus('Task saved successfully!');
}

// NEW save persona
async function savePersona() {
  const name = document.getElementById('personaNameInput').value.trim();
  let addendum = document.getElementById('personaAddendumInput').value.trim();
  if (!name || !addendum) {
    alert('Persona name and text prompt are required.');
    return;
  }
  const obj = { name, systemAddendum: addendum };
  if (editingPersonaKey) {
    currentPersonas[editingPersonaKey] = obj;
  } else {
    const key = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    currentPersonas[key] = obj;
  }
  await chrome.storage.sync.set({ personas: currentPersonas });
  renderPersonas();
  hydrateActiveSelectors();
  updateEffectiveSystemPrompt();
  closePersonaModal();
  showSaveStatus('Persona saved');
}

// Delete task
async function deleteTask(key) {
  if (confirm(`Are you sure you want to delete the task "${currentTasks[key].name}"?`)) {
    delete currentTasks[key];
    await chrome.storage.sync.set({ tasks: currentTasks });
    renderTasks();
    hydrateActiveSelectors();
    updateEffectiveSystemPrompt();
    showSaveStatus('Task deleted');
  }
}

// NEW delete persona
async function deletePersona(key) {
  if (!currentPersonas[key]) return;
  if (DEFAULT_PERSONAS[key]) {
    alert('Default personas cannot be deleted.');
    return;
  }
  if (!confirm(`Delete persona "${currentPersonas[key].name}"?`)) return;
  delete currentPersonas[key];
  if (currentPersonaActive === key) {
    currentPersonaActive = 'general';
    await chrome.storage.sync.set({ currentPersona: currentPersonaActive });
  }
  await chrome.storage.sync.set({ personas: currentPersonas });
  renderPersonas();
  hydrateActiveSelectors();
  updateEffectiveSystemPrompt();
  showSaveStatus('Persona deleted');
}

// Save settings
async function saveSettings() {
  const useRemoteVLM = document.getElementById('useRemoteVLM').checked;
  const remoteVLMEndpoint = document.getElementById('remoteVLMEndpoint').value.trim() || DEFAULT_REMOTE_VLM.remoteVLMEndpoint;
  const remoteVLMModel = document.getElementById('remoteVLMModel').value.trim() || DEFAULT_REMOTE_VLM.remoteVLMModel;
  const remoteVLMApiKey = document.getElementById('remoteVLMApiKey').value.trim();
  
  await chrome.storage.sync.set({
    useRemoteVLM,
    remoteVLMEndpoint,
    remoteVLMModel
  });
  await chrome.storage.local.set({ remoteVLMApiKey });
  
  showSaveStatus('Settings saved!');
}

// Extend reset to also restore personas
async function resetToDefaults() {
  if (confirm('Reset all settings to defaults? This will remove custom tasks and personas.')) {
    currentTasks = DEFAULT_TASKS;
    currentPersonas = DEFAULT_PERSONAS;
    currentPersonaActive = 'general';
    systemPromptTemplate = buildDefaultTemplate(boilerplateText);
    await chrome.storage.sync.set({
      tasks: DEFAULT_TASKS,
      personas: DEFAULT_PERSONAS,
      currentTask: 'simple',
      currentPersona: 'general',
      enabled: true,
      systemPromptTemplate,
      useRemoteVLM: DEFAULT_REMOTE_VLM.useRemoteVLM,
      remoteVLMEndpoint: DEFAULT_REMOTE_VLM.remoteVLMEndpoint,
      remoteVLMModel: DEFAULT_REMOTE_VLM.remoteVLMModel
    });
    await chrome.storage.local.set({ remoteVLMApiKey: DEFAULT_REMOTE_VLM.remoteVLMApiKey });
    await loadSettings();
    hydrateActiveSelectors();
    updateEffectiveSystemPrompt();
    showSaveStatus('Reset to defaults');
  }
}

function showSaveStatus(message) {
  const status = document.getElementById('saveStatus');
  status.textContent = message;
  setTimeout(() => {
    status.textContent = '';
  }, 3000);
}

function applyTemplate(template, taskText, personaText) {
  return template
    .replace(/\{task\}/gi, () => taskText)
    .replace(/\{persona\}/gi, () => personaText);
}

function queueSystemPromptSave() {
  const templateEl = document.getElementById('systemPromptTemplate');
  if (!templateEl) return;
  systemPromptTemplate = templateEl.value;
  updateEffectiveSystemPrompt();
  if (templateSaveTimer) clearTimeout(templateSaveTimer);
  templateSaveTimer = setTimeout(async () => {
    await chrome.storage.sync.set({ systemPromptTemplate });
    showSaveStatus('System prompt template saved');
  }, 400);
}

async function restoreSystemPromptTemplate() {
  const templateEl = document.getElementById('systemPromptTemplate');
  if (!templateEl) return;
  systemPromptTemplate = buildDefaultTemplate(boilerplateText);
  templateEl.value = systemPromptTemplate;
  updateEffectiveSystemPrompt();
  await chrome.storage.sync.set({ systemPromptTemplate });
  showSaveStatus('System prompt template restored');
}
