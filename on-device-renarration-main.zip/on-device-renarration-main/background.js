// Background service worker for the extension
// Handles message passing and model management (WebLLM via offscreen document)

// Default user tasks
const DEFAULT_TASKS = {
  'simple': {
    name: 'Simple Language',
    textPrompt:
      'You are performing a re-narration task. Express the given text in simple, easy-to-understand language with short sentences and plain vocabulary suitable for a general audience.',
    imagePrompt:
      'You are describing an image in plain, accessible language. Keep sentences short and avoid technical terms.',
    maxLength: 150
  },
  'detailed': {
    name: 'Detailed Explanation',
    textPrompt:
      'You are performing a re-narration task. Produce a detailed and comprehensive version of the given text that adds clarity, elaboration, and logical flow while remaining faithful to the original meaning.',
    imagePrompt:
      'You are describing an image in a detailed way. Cover all visible elements, relationships, and contextual features.',
    maxLength: 300
  },
  'academic': {
    name: 'Academic Style',
    textPrompt:
      'You are performing a re-narration task. Render the given text in formal academic language, using precise terminology and structured phrasing consistent with scholarly writing.',
    imagePrompt:
      'You are describing an image in an academic tone, focusing on analytical, objective, and domain-appropriate terminology.',
    maxLength: 250
  },
  'summary': {
    name: 'Summary',
    textPrompt:
      'You are performing a re-narration task. Summarize the given text concisely, keeping only the essential ideas and expressing them clearly and neutrally.',
    imagePrompt:
      'You are summarizing the content of an image briefly, noting only the key elements or actions depicted.',
    maxLength: 100
  }
};

// Add default personas
const DEFAULT_PERSONAS = {
  'berat': {
    name: 'Berat (Neighborhood Barber)',
    description: 'Low computer literacy; prefers very plain Turkish/English explanations.',
    systemAddendum: 'Target audience persona: Berat is a neighborhood barber with limited computer experience. Use very plain language and avoid economic jargon.'
  },
  'student': {
    name: 'Undergrad Student',
    description: 'Understands basic academic concepts; wants clear but not oversimplified explanations.',
    systemAddendum: 'Target audience persona: An undergraduate student seeking clear educational explanations with light context.'
  },
  'researcher': {
    name: 'Academic Researcher',
    description: 'Prefers formal, precise, domain-rich terminology.',
    systemAddendum: 'Target audience persona: Academic researcher expecting formal tone with precise terminology.'
  },
  'general': {
    name: 'General Public',
    description: 'Average reader; keep it accessible and neutral.',
    systemAddendum: 'Target audience persona: General public; keep tone neutral and accessible.'
  },
  'gamer_student': {
  name: 'High-School Gamer',
  description: 'High school student, enjoys video games; prefers casual, engaging explanations with relatable metaphors.',
  systemAddendum:
    'Target audience persona: High-school student who enjoys video games. Use casual, energetic language, short sentences, and relatable game-based metaphors when appropriate. Avoid heavy jargon; if technical terms are needed, briefly define them using simple analogies.'
},

'smallbiz_owner': {
  name: 'Small Business Owner',
  description: 'Runs a small business and handles basic accounting in Excel; prefers direct, practical, and actionable explanations.',
  systemAddendum:
    'Target audience persona: Small business owner who performs accounting tasks (often in Excel). Provide clear, step-by-step guidance, prioritize practical examples and actionable items, and show short illustrative snippets (e.g., Excel formulas or brief workflow steps) when relevant. Keep language concise and business-focused.'
},

'arch_student': {
  name: 'Architecture Student',
  description: 'University architecture student experienced with 3D design tools and technical drawings; prefers precise, design-oriented language.',
  systemAddendum:
    'Target audience persona: University student majoring in architecture who frequently uses 3D design software. Use precise, domain-relevant terminology (but define very specialized terms if they are uncommon), reference spatial concepts and design workflow when useful, and give examples that can map to 3D modeling or drafting steps. Keep explanations structured and include suggested practical next steps for application in design software.'
}
};

async function getSettingsWithTaskMigration(extraKeys = []) {
  const keys = new Set([
    'tasks',
    'currentTask',
    'profiles',
    'currentProfile',
    ...extraKeys
  ]);
  const settings = await chrome.storage.sync.get([...keys]);
  let tasks = settings.tasks;
  let currentTask = settings.currentTask;
  let shouldWrite = false;

  if ((!tasks || !Object.keys(tasks).length) && settings.profiles && Object.keys(settings.profiles).length) {
    tasks = settings.profiles;
    shouldWrite = true;
  }
  if (!currentTask && settings.currentProfile) {
    currentTask = settings.currentProfile;
    shouldWrite = true;
  }
  if (!tasks || !Object.keys(tasks).length) {
    tasks = DEFAULT_TASKS;
    shouldWrite = true;
  }
  if (!currentTask) {
    currentTask = Object.keys(tasks)[0] || 'simple';
    shouldWrite = true;
  }

  if (shouldWrite) {
    await chrome.storage.sync.set({ tasks, currentTask });
  }

  return { ...settings, tasks, currentTask };
}

// Track pending requests routed through the offscreen document
const pendingOffscreenResponses = new Map();
const PIPELINE_LOG_KEY = 'pipelineLogs';

// Initialize default settings
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    enabled: true,
    currentTask: 'simple',
    tasks: DEFAULT_TASKS,
    useWebLLM: true,
    webllmModel: 'gemma-2-2b-it-q4f16_1-MLC',
    useWebVLM: false,
    webvlmModel: 'Phi-3.5-vision-instruct-q4f16_1-MLC',
    useRemoteVLM: true,
    remoteVLMModel: 'gemini-2.0-flash',
    remoteVLMEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
    personas: DEFAULT_PERSONAS,
    currentPersona: 'general'
  });
  chrome.storage.local.set({ remoteVLMApiKey: '' });
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request?.__offscreenResponse) {
    const pending = pendingOffscreenResponses.get(request.requestId);
    if (pending) {
      clearTimeout(pending.timeoutId);
      pendingOffscreenResponses.delete(request.requestId);
      pending.resolve(request.payload);
    }
    return;
  }

  if (request.action === 'renarrate-text') {
    renarrateText(request.text, request.task).then(sendResponse);
    return true; // Keep message channel open for async response
  } else if (request.action === 'describe-image') {
    describeImage(request.imageUrl, request.task).then(sendResponse);
    return true;
  } else if (request.action === 'get-settings') {
    getSettingsWithTaskMigration([
      'enabled',
      'useWebLLM',
      'webllmModel',
      'useWebVLM',
      'webvlmModel',
      'useRemoteVLM',
      'remoteVLMModel',
      'remoteVLMEndpoint',
      'personas',
      'currentPersona'
    ]).then(sendResponse);
    return true;
  } else if (request.action === 'webllm-init') {
    // Allow UI to explicitly initialize engine
    ensureOffscreen()
      .then(async () => {
        const { webllmModel } = await chrome.storage.sync.get(['webllmModel']);
        return postToOffscreen({ type: 'webllm-init', payload: { modelId: webllmModel } });
      })
      .then(sendResponse);
    return true;
  } else if (request.action === 'run-test-cases') {
    runTestCases().then(sendResponse);
    return true;
  } else if (request.action === 'get-logs') {
    chrome.storage.local.get(['testLogs']).then(data => sendResponse({ success: true, logs: data.testLogs || [] }));
    return true;
  } else if (request.action === 'evaluate-log-entry') {
    evaluateLog(request.testId, request.evaluation).then(sendResponse);
    return true;
  } else if (request.action === 'export-logs') {
    exportLogs().then(sendResponse);
    return true;
  } else if (request.action === 'clear-logs') {
    chrome.storage.local.set({ testLogs: [], completedTestIds: [] }).then(() => sendResponse({ success: true }));
    return true;
  } else if (request.action === 'capture-fullpage') {
    // Trigger full-page screenshot capture and open viewer
    captureFullPageScreenshots(sender?.tab?.id).then(sendResponse);
    return true;
  } else if (request.action === 'describe-page-screenshot') {
    describePageScreenshot(sender?.tab?.id).then(sendResponse);
    return true;
  } else if (request.action === 'renarrate-page') {
    renarratePage(sender?.tab?.id).then(sendResponse);
    return true;
  } else if (request.action === 'get-pipeline-logs') {
    getPipelineLogs().then(sendResponse);
    return true;
  } else if (request.action === 'clear-pipeline-logs') {
    clearPipelineLogs().then(sendResponse);
    return true;
  } else if (request.action === 'delete-pipeline-entry') {
    deletePipelineEntry(request.runId, request.stage).then(sendResponse);
    return true;
  } else if (request.action === 'toggle-pipeline-star') {
    togglePipelineStar(request.runId, request.stage).then(sendResponse);
    return true;
  }
});

// Simulate text renarration with local LLM
// In a production version, this would use Web LLM or similar on-device model
async function renarrateText(text, taskName, overrideTask, options = {}) {
  const settings = await getSettingsWithTaskMigration([
    'useWebLLM',
    'webllmModel',
    'personas',
    'currentPersona',
    'systemPromptTemplate'
  ]);
  const tasks = settings.tasks || DEFAULT_TASKS;
  const baseTask = tasks[taskName || settings.currentTask] || tasks.simple || DEFAULT_TASKS.simple;
  const task = overrideTask || baseTask;
  const effectiveModelId = options?.modelId || settings.webllmModel;

  // Determine persona to apply (test case override > explicit text > global selection)
  let persona = null;
  if (options?.personaKey && settings.personas?.[options.personaKey]) {
    persona = settings.personas[options.personaKey];
  } else if (typeof options?.personaText === 'string' && options.personaText.trim()) {
    const addendum = options.personaText.trim();
    persona = {
      name: options.personaKey || 'Custom Persona',
      description: options.personaText.trim(),
      systemAddendum: addendum
    };
  } else {
    persona = settings.personas?.[settings.currentPersona];
  }

  const basePrompt = task?.textPrompt || '';
  const personaText = persona ? (persona.systemAddendum || persona.description || '') : '';
  const boilerplate = await getSystemBoilerplate();
  const systemPrompt = applyPromptTemplate(
    settings.systemPromptTemplate,
    basePrompt,
    personaText,
    boilerplate
  );
  const personaAugmentedTask = { ...task, textPrompt: systemPrompt };

  const maxOutputTokens = personaAugmentedTask?.maxLength
    ? Math.max(64, Math.min(512, Math.ceil(personaAugmentedTask.maxLength * 1.5)))
    : 256;
  const offscreenTimeoutMs = Math.max(90000, Math.min(240000, maxOutputTokens * 400));
  const promptInfo = {
    systemPrompt: personaAugmentedTask?.textPrompt || '',
    userText: truncateForContext(text)
  };

  // Try WebLLM in offscreen document if enabled
  if (settings.useWebLLM) {
    try {
      await ensureOffscreen();
      const response = await postToOffscreen({
        type: 'webllm-renarrate-text',
        payload: {
          text: promptInfo.userText,
          task: personaAugmentedTask,
          modelId: effectiveModelId,
          maxOutputTokens
        }
      }, { timeoutMs: offscreenTimeoutMs });
      if (response && response.success) return { ...response, promptInfo };
      // If offscreen returns error, fall through to simulator
      console.warn('WebLLM failed, falling back to simulator:', response && response.error);
    } catch (e) {
      console.warn('Offscreen/WebLLM unavailable, falling back:', e && e.message);
    }
  }
  // Fallback: simulate processing with local model
  const renarrated = await simulateLocalLLM(text, personaAugmentedTask);
  return { success: true, result: renarrated, promptInfo };
}

const DEFAULT_REMOTE_VLM_PROMPT = [
  'You see screenshot slices of an entire webpage, in order from top to bottom.',
  'Transcribe important textual content exactly as shown (headings, body paragraphs, link/label text).',
  'Keep wording tight and ordered; lightly condense filler/repeated boilerplate.',
  'Include brief notes for meaningful images/graphics and layout cues (sidebars, callouts, tables) only when they convey information.',
  'Do NOT include ads, promo banners, cookie banners, newsletter popups, or other promotional/utility chrome (nav bars, footers, repeated menus); skip them entirely.',
  'If text flows across slices (e.g., an article continues), merge it into a single continuous section.',
  'Hard cap the response at about 8,000 characters (~1,200 words); prioritize main content, merge repeats, and drop filler to stay under the cap.',
  'Prefer concise bullets or short paragraphs; do not repeat headings or navigation items.',
  'Return a single structured outline in plain text. Respect the order of slices as they appear.'
].join(' ');

let cachedSystemBoilerplate = null;
let cachedRemoteVlmPrompt = null;
function buildDefaultPromptTemplate(boilerplate) {
  const parts = [];
  const base = (boilerplate || '').trim();
  if (base) parts.push(base);
  parts.push('Task:\n{task}');
  parts.push('Persona:\n{persona}');
  return parts.join('\n\n');
}

function applyPromptTemplate(template, taskText, personaText, boilerplate) {
  const source = (template || '').trim() || buildDefaultPromptTemplate(boilerplate);
  return source
    .replace(/\{task\}/gi, () => taskText || '')
    .replace(/\{persona\}/gi, () => personaText || '')
    .trim();
}
async function getSystemBoilerplate() {
  if (cachedSystemBoilerplate) return cachedSystemBoilerplate;
  try {
    const res = await fetch(chrome.runtime.getURL('src/prompts/system.md'));
    if (!res.ok) throw new Error('Failed to load system prompt');
    const txt = await res.text();
    cachedSystemBoilerplate = txt.trim();
    return cachedSystemBoilerplate;
  } catch (e) {
    console.warn('System prompt fetch failed, using fallback:', e?.message || e);
    cachedSystemBoilerplate = '';
    return '';
  }
}

async function getRemoteVlmPrompt() {
  if (cachedRemoteVlmPrompt) return cachedRemoteVlmPrompt;
  try {
    const res = await fetch(chrome.runtime.getURL('src/prompts/vlm.md'));
    if (!res.ok) throw new Error('Failed to load VLM prompt');
    const txt = (await res.text()).trim();
    cachedRemoteVlmPrompt = txt || DEFAULT_REMOTE_VLM_PROMPT;
    return cachedRemoteVlmPrompt;
  } catch (e) {
    console.warn('VLM prompt fetch failed, using fallback:', e?.message || e);
    cachedRemoteVlmPrompt = DEFAULT_REMOTE_VLM_PROMPT;
    return cachedRemoteVlmPrompt;
  }
}

// Simulate image description with local VLM
// In a production version, this would use Web VLM or similar on-device model
async function describeImage(imageUrl, taskName) {
  try {
    const settings = await getSettingsWithTaskMigration([
      'useWebLLM',
      'useWebVLM',
      'webvlmModel',
      'useRemoteVLM',
      'remoteVLMModel',
      'remoteVLMEndpoint'
    ]);
    const { remoteVLMApiKey } = await chrome.storage.local.get(['remoteVLMApiKey']);
    const tasks = settings.tasks || DEFAULT_TASKS;
    const task = tasks[taskName || settings.currentTask] || tasks.simple || DEFAULT_TASKS.simple;
    // Placeholder for future on-device VLM
    if (settings.useWebVLM) {
      console.warn('WebVLM placeholder enabled but not implemented; using remote/simulator.');
    }
    // Try remote VLM first if configured
    if (settings.useRemoteVLM && remoteVLMApiKey) {
      try {
        const imageDataUrl = await toDataUrl(imageUrl);
        const remote = await callRemoteVLM({
          imageDataUrl,
          prompt: task?.imagePrompt || 'Describe this image accurately. Transcribe any visible text exactly.',
          model: settings.remoteVLMModel,
          endpoint: settings.remoteVLMEndpoint,
          apiKey: remoteVLMApiKey,
          mode: 'describe'
        });
        if (remote?.success) return remote;
      } catch (err) {
        console.warn('Remote VLM failed, falling back:', err && err.message);
      }
    }
    // For now, image description remains simulated unless WebLLM VLM is integrated
    if (settings.useWebLLM) {
      try {
        await ensureOffscreen();
        const response = await postToOffscreen({
          type: 'webllm-describe-image',
          payload: { imageUrl, task, modelId: settings.webllmModel }
        }, { timeoutMs: 90000 });
        if (response && response.success) return response;
      } catch (e) {
        // ignore, fall back
      }
    }
    const description = await simulateLocalVLM(imageUrl, task);
    return { success: true, result: description };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Simulate local LLM processing
// In production, replace with actual Web LLM implementation
async function simulateLocalLLM(text, task) {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const originalLength = text.length;
  const words = text.split(/\s+/);
  const fallbackMaxLength = Math.min(200, originalLength);
  const maxLength = Number.isFinite(task?.maxLength) && task.maxLength > 0
    ? task.maxLength
    : fallbackMaxLength;
  
  // Simple simulation based on task
  switch (task.name) {
    case 'Simple Language':
      // Simplify by using shorter sentences
      return `Simplified version: ${text.substring(0, Math.min(maxLength, originalLength))}. This means the content is about ${words.length} key ideas presented in an easier way.`;
    
    case 'Detailed Explanation':
      return `Detailed analysis: ${text}\n\nThis text contains ${words.length} words and covers several important points. The main ideas are interconnected and provide comprehensive information about the topic.`;
    
    case 'Academic Style':
      return `In scholarly terms, the aforementioned content posits: ${text.substring(0, Math.min(maxLength, originalLength))}. This represents a formal interpretation of the source material.`;
    
    case 'Summary':
      return `Brief summary: ${text.substring(0, Math.min(100, originalLength))}...`;
    
    default:
      return text;
  }
}

// Simulate local VLM processing
// In production, replace with actual Web VLM implementation
async function simulateLocalVLM(imageUrl, task) {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Extract image characteristics from URL or filename
  const imageName = imageUrl.split('/').pop().split('?')[0];
  
  // Simple simulation based on task
  switch (task.name) {
    case 'Simple Language':
      return `This is an image showing visual content. The image appears to be "${imageName}". It contains various elements arranged on the page.`;
    
    case 'Detailed Explanation':
      return `Comprehensive image analysis: This image (${imageName}) contains multiple visual elements. The composition includes foreground and background elements with specific positioning. Colors, shapes, and textures contribute to the overall visual message. The image serves a specific purpose within the context of the page.`;
    
    case 'Academic Style':
      return `Visual analysis: The image denoted as "${imageName}" presents a structured composition wherein various elements are arranged according to design principles. The visual hierarchy and spatial relationships suggest intentional placement for communicative purposes.`;
    
    case 'Summary':
      return `Image: ${imageName} - Contains visual elements relevant to the page content.`;
    
    default:
      return `Image description: ${imageName}`;
  }
}

// Capture current viewport and send to remote VLM for full-page content extraction
async function describePageScreenshot(tabId) {
  try {
    const settings = await chrome.storage.sync.get([
      'useRemoteVLM',
      'remoteVLMModel',
      'remoteVLMEndpoint'
    ]);
    const { remoteVLMApiKey } = await chrome.storage.local.get(['remoteVLMApiKey']);
    if (!settings.useRemoteVLM) return { success: false, error: 'Remote VLM is disabled in settings.' };
    if (!remoteVLMApiKey) return { success: false, error: 'Remote VLM API key is missing.' };

    const runId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2);
    const logBase = { runId, timestampIso: new Date().toISOString() };
    const captureStarted = Date.now();

    const tab = tabId ? await chrome.tabs.get(tabId) : await getActiveTab();
    const pageTitle = tab?.title || '';
    const { images } = await captureFullPageSlices(tab?.id);
    if (!images || !images.length) return { success: false, error: 'Failed to capture page.' };
    await appendPipelineLog({
      ...logBase,
      stage: 'capture',
      success: true,
      sliceCount: images.length,
      url: tab?.url,
      title: pageTitle,
      durationMs: Date.now() - captureStarted,
      content: `Screenshots captured (${images.length})`
    });

    const prompt = await getRemoteVlmPrompt();

    const vlmStart = Date.now();
    const remote = await callRemoteVLMWithImages({
      images,
      prompt,
      model: settings.remoteVLMModel,
      endpoint: settings.remoteVLMEndpoint,
      apiKey: remoteVLMApiKey
    });
    if (!remote?.success) {
      await appendPipelineLog({
        ...logBase,
        stage: 'vlm',
        success: false,
        error: remote?.error || 'Remote VLM failed',
        model: settings.remoteVLMModel,
        url: tab?.url,
        title: pageTitle,
        durationMs: Date.now() - vlmStart
      });
      return { success: false, error: remote?.error || 'Remote VLM failed.' };
    }
    await appendPipelineLog({
      ...logBase,
      stage: 'vlm',
      success: true,
      model: settings.remoteVLMModel,
      content: remote.result,
      input: {
        prompt,
        imageCount: images.length
      },
      url: tab?.url,
      title: pageTitle,
      durationMs: Date.now() - vlmStart
    });

    const combined = remote.result;
    const previewThumb = images[0]?.dataUrl ? await createThumbnail(images[0].dataUrl, 240, 240) : '';
    
    // Debug: log sizes before storing
    console.log(`[describePageScreenshot] previewThumb size: ${(previewThumb?.length || 0)/1024} KB`);
    console.log(`[describePageScreenshot] combined content size: ${(combined?.length || 0)/1024} KB`);
    
    try {
      await chrome.storage.local.set({
        lastDescribeImage: previewThumb || '',
        lastDescribeResult: {
          content: combined,
          model: settings.remoteVLMModel,
          at: new Date().toISOString(),
          runId
        }
      });
      console.log(`[describePageScreenshot] Stored lastDescribeResult successfully`);
    } catch (e) {
      console.error(`[describePageScreenshot] Storage failed:`, e.message);
      // Store without thumbnail
      await chrome.storage.local.set({
        lastDescribeImage: '',
        lastDescribeResult: {
          content: combined?.slice(0, 10000) || '',
          model: settings.remoteVLMModel,
          at: new Date().toISOString(),
          runId
        }
      });
    }
    return { success: true, result: combined, runId, url: tab?.url, title: pageTitle };
  } catch (error) {
    return { success: false, error: error?.message || String(error) };
  }
}

// Full pipeline: capture -> remote VLM -> LLM renarration
async function renarratePage(tabId) {
  try {
    const describe = await describePageScreenshot(tabId);
    if (!describe?.success) return describe;
    const vlmContent = describe.result || '';
    const llmStart = Date.now();
    const renarrated = await renarrateText(vlmContent, null, null, { runId: describe.runId });
    if (!renarrated?.success) {
      await appendPipelineLog({
        runId: describe.runId || (Math.random().toString(36).slice(2)),
        timestampIso: new Date().toISOString(),
        stage: 'llm',
        success: false,
        error: renarrated.error || 'LLM renarration failed',
        model: (await chrome.storage.sync.get(['webllmModel'])).webllmModel,
        url: describe.url,
        title: describe.title,
        durationMs: Date.now() - llmStart
      });
      return renarrated;
    }
    await appendPipelineLog({
      runId: describe.runId || (Math.random().toString(36).slice(2)),
      timestampIso: new Date().toISOString(),
      stage: 'llm',
      success: true,
      content: renarrated.result,
      input: renarrated.promptInfo,
      model: (await chrome.storage.sync.get(['webllmModel'])).webllmModel,
      url: describe.url,
      title: describe.title,
      durationMs: Date.now() - llmStart
    });
    
    // Debug: log sizes
    const vlmSize = (vlmContent?.length || 0) / 1024;
    const renSize = (renarrated.result?.length || 0) / 1024;
    console.log(`[renarratePage] vlmContent: ${vlmSize.toFixed(2)} KB, renarration: ${renSize.toFixed(2)} KB`);
    
    try {
      await chrome.storage.local.set({
        lastPageRenarration: {
          vlmContent: vlmContent?.slice(0, 20000) || '',
          renarration: renarrated.result?.slice(0, 20000) || '',
          at: new Date().toISOString()
        }
      });
      console.log(`[renarratePage] Stored lastPageRenarration successfully`);
    } catch (e) {
      console.error(`[renarratePage] Storage failed:`, e.message);
    }
    return { success: true, vlmContent, renarration: renarrated.result, runId: describe.runId };
  } catch (error) {
    return { success: false, error: error?.message || String(error) };
  }
}

// Utilities for remote VLM (hosted) calls
async function toDataUrl(imageUrl) {
  const res = await fetch(imageUrl);
  if (!res.ok) throw new Error(`Failed to fetch image: ${res.status}`);
  const blob = await res.blob();
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

async function callRemoteVLM({ imageDataUrl, prompt, model, endpoint, apiKey, mode }) {
  if (!endpoint || !model || !apiKey) return { success: false, error: 'Missing remote VLM configuration' };
  const url = endpoint.replace('{model}', model).includes('key=')
    ? endpoint.replace('{model}', model)
    : `${endpoint.replace('{model}', model)}${endpoint.includes('?') ? '&' : '?'}key=${encodeURIComponent(apiKey)}`;
  const base64 = imageDataUrl.split(',')[1];
  const body = {
    contents: [
      {
        parts: [
          { text: prompt || 'Describe this image.' },
          { inline_data: { mime_type: 'image/png', data: base64 } }
        ]
      }
    ],
    generationConfig: {
      temperature: mode === 'describe' ? 0.2 : 0
    }
  };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 120000);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    clearTimeout(timer);
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`Remote VLM error: ${res.status} ${text}`);
    }
    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text).join('\n').trim();
    if (!text) return { success: false, error: 'No content returned from remote VLM' };
    return { success: true, result: text, source: 'remote-vlm' };
  } catch (err) {
    clearTimeout(timer);
    return { success: false, error: err?.message || String(err) };
  }
}

async function callRemoteVLMWithImages({ images, prompt, model, endpoint, apiKey }) {
  if (!Array.isArray(images) || images.length === 0) return { success: false, error: 'No images provided' };
  if (!endpoint || !model || !apiKey) return { success: false, error: 'Missing remote VLM configuration' };
  const url = endpoint.replace('{model}', model).includes('key=')
    ? endpoint.replace('{model}', model)
    : `${endpoint.replace('{model}', model)}${endpoint.includes('?') ? '&' : '?'}key=${encodeURIComponent(apiKey)}`;

  const parts = [{ text: prompt || 'Describe these images.' }];
  images.forEach((img, idx) => {
    if (!img?.dataUrl) return;
    const base64 = img.dataUrl.split(',')[1];
    parts.push({ inline_data: { mime_type: 'image/png', data: base64 } });
    parts.push({ text: `Slice ${idx + 1} of ${images.length}` });
  });

  const body = {
    contents: [
      {
        parts
      }
    ],
    generationConfig: {
      temperature: 0.2
    }
  };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 120000);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    clearTimeout(timer);
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`Remote VLM error: ${res.status} ${text}`);
    }
    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text).join('\n').trim();
    if (!text) return { success: false, error: 'No content returned from remote VLM' };
    return { success: true, result: text, source: 'remote-vlm' };
  } catch (err) {
    clearTimeout(timer);
    return { success: false, error: err?.message || String(err) };
  }
}

async function getPipelineLogs() {
  const { pipelineLogs = [] } = await chrome.storage.local.get([PIPELINE_LOG_KEY]);
  return { success: true, logs: pipelineLogs };
}

async function clearPipelineLogs() {
  await chrome.storage.local.set({ [PIPELINE_LOG_KEY]: [] });
  return { success: true };
}

async function appendPipelineLog(entry) {
  let { pipelineLogs = [] } = await chrome.storage.local.get([PIPELINE_LOG_KEY]);
  
  // Clean old logs that might have images (migration cleanup)
  pipelineLogs = pipelineLogs.map(log => {
    if (log.input?.images) {
      const cleaned = { ...log, input: { ...log.input, imageCount: log.input.images.length } };
      delete cleaned.input.images;
      return cleaned;
    }
    return log;
  });
  
  const enriched = { starred: false, ...entry };
  const cleaned = await sanitizeLogEntry(enriched);
  
  // Debug: log sizes
  const cleanedSize = JSON.stringify(cleaned).length;
  const existingSize = JSON.stringify(pipelineLogs).length;
  console.log(`[appendPipelineLog] Entry size: ${(cleanedSize/1024).toFixed(2)} KB, Existing logs size: ${(existingSize/1024).toFixed(2)} KB, Entry count: ${pipelineLogs.length}`);
  
  const next = [cleaned, ...pipelineLogs].slice(0, 100);
  const nextSize = JSON.stringify(next).length;
  console.log(`[appendPipelineLog] Total size to store: ${(nextSize/1024).toFixed(2)} KB`);
  
  // If still too large (> 2MB), aggressively trim
  let toStore = next;
  if (nextSize > 2 * 1024 * 1024) {
    console.warn(`[appendPipelineLog] Size too large, trimming to 20 entries`);
    toStore = next.slice(0, 20);
  }
  
  try {
    await chrome.storage.local.set({ [PIPELINE_LOG_KEY]: toStore });
    console.log(`[appendPipelineLog] Success storing ${toStore.length} entries`);
  } catch (e) {
    console.error(`[appendPipelineLog] Storage failed:`, e.message);
    // Aggressive retry: keep only 10 most recent, truncate content
    const minimal = toStore.slice(0, 10).map(log => ({
      ...log,
      content: log.content?.slice(0, 1000) || '',
      input: log.input ? { imageCount: log.input.imageCount, prompt: log.input.prompt?.slice(0, 500) } : undefined
    }));
    const minimalSize = JSON.stringify(minimal).length;
    console.log(`[appendPipelineLog] Minimal retry size: ${(minimalSize/1024).toFixed(2)} KB with ${minimal.length} entries`);
    try {
      await chrome.storage.local.set({ [PIPELINE_LOG_KEY]: minimal });
      console.log(`[appendPipelineLog] Minimal retry success`);
    } catch (e2) {
      console.error(`[appendPipelineLog] Minimal retry also failed, clearing logs:`, e2.message);
      await chrome.storage.local.set({ [PIPELINE_LOG_KEY]: [] });
    }
  }
}

async function deletePipelineEntry(runId, stage) {
  const { pipelineLogs = [] } = await chrome.storage.local.get([PIPELINE_LOG_KEY]);
  const filtered = pipelineLogs.filter(l => !(l.runId === runId && l.stage === stage));
  await chrome.storage.local.set({ [PIPELINE_LOG_KEY]: filtered });
  return { success: true };
}

async function togglePipelineStar(runId, stage) {
  const { pipelineLogs = [] } = await chrome.storage.local.get([PIPELINE_LOG_KEY]);
  const next = pipelineLogs.map(l => {
    if (l.runId === runId && l.stage === stage) {
      return { ...l, starred: !l.starred };
    }
    return l;
  });
  await chrome.storage.local.set({ [PIPELINE_LOG_KEY]: next });
  return { success: true };
}

async function sanitizeLogEntry(entry) {
  const clone = { ...entry };
  if (clone.content && clone.content.length > 8000) {
    clone.content = clone.content.slice(0, 8000) + '...';
  }
  // Images are no longer stored in logs to save memory
  if (clone.input?.images) {
    clone.input = { ...clone.input, imageCount: clone.input.images.length };
    delete clone.input.images;
  }
  return clone;
}

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  // Popup will handle the UI
});

// -----------------
// Offscreen document
// -----------------
let creatingOffscreen;

async function hasOffscreenDocument() {
  const matched = await chrome.offscreen.hasDocument?.();
  // Older Chrome versions don't have hasDocument; try getting clients
  if (typeof matched === 'boolean') return matched;
  try {
    const clients = await chrome.runtime.getContexts?.({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [chrome.runtime.getURL('offscreen.html')]
    });
    return (clients && clients.length > 0) || false;
  } catch (e) {
    return false;
  }
}

async function ensureOffscreen() {
  if (await hasOffscreenDocument()) return;
  if (creatingOffscreen) return creatingOffscreen;
  creatingOffscreen = chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: [ 'IFRAME_SCRIPTING' ],
    justification: 'Run WebLLM with WebGPU in an offscreen document for on-device inference.'
  }).catch((e) => {
    console.error('Failed to create offscreen document:', e);
    throw e;
  }).finally(() => {
    creatingOffscreen = null;
  });
  return creatingOffscreen;
}

function postToOffscreen(message, options = {}) {
  const timeoutMs = options.timeoutMs ?? 120000;
  return new Promise((resolve) => {
    const requestId = Math.random().toString(36).slice(2);
    const timeoutId = setTimeout(() => {
      if (!pendingOffscreenResponses.has(requestId)) return;
      pendingOffscreenResponses.delete(requestId);
      resolve({ success: false, error: 'Offscreen timeout' });
    }, timeoutMs);

    pendingOffscreenResponses.set(requestId, { resolve, timeoutId });

    chrome.runtime.sendMessage({ __toOffscreen: true, requestId, ...message }, () => {
      const sendError = chrome.runtime.lastError;
      if (sendError) {
        const pending = pendingOffscreenResponses.get(requestId);
        if (pending) {
          clearTimeout(pending.timeoutId);
          pendingOffscreenResponses.delete(requestId);
          resolve({ success: false, error: sendError.message });
        }
      }
    });
  });
}

function truncateForContext(text, maxChars = 20000) {
  if (!text || text.length <= maxChars) return text;
  return text.slice(0, maxChars);
}

async function createThumbnail(dataUrl, maxW = 240, maxH = 240) {
  const res = await fetch(dataUrl);
  const blob = await res.blob();
  const bmp = await createImageBitmap(blob);
  const ratio = Math.min(maxW / bmp.width, maxH / bmp.height, 1);
  const w = Math.max(1, Math.round(bmp.width * ratio));
  const h = Math.max(1, Math.round(bmp.height * ratio));
  const canvas = new OffscreenCanvas(w, h);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bmp, 0, 0, w, h);
  bmp.close && bmp.close();
  const thumbBlob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.7 });
  return await blobToDataUrl(thumbBlob);
}

// In-memory cache of logs (persisted in storage.local)
async function appendLog(entry) {
  const existing = await chrome.storage.local.get(['testLogs']);
  const logs = existing.testLogs || [];
  logs.push(entry);
  await chrome.storage.local.set({ testLogs: logs });
  return entry;
}

// Fetch test cases config
async function loadTestCases() {
  const url = chrome.runtime.getURL('config/test-cases.json');
  const res = await fetch(url);
  return res.json();
}

// Run all test cases sequentially
async function runTestCases() {
  const cases = await loadTestCases();
  // Load tasks/personas plus any existing logs and completed ids
  const settings = await getSettingsWithTaskMigration([
    'webllmModel',
    'useWebLLM',
    'personas',
    'currentPersona'
  ]);
  const { testLogs: existingLogs = [], completedTestIds = [] } = await chrome.storage.local.get(['testLogs','completedTestIds']);
  const completed = new Set(completedTestIds.length ? completedTestIds : existingLogs.map(l => l.testId));
  const globalPersona = settings.personas?.[settings.currentPersona];
  const tasks = settings.tasks || DEFAULT_TASKS;
  const allLogs = [...existingLogs];
  for (const tc of cases) {
    // Skip if already completed
    if (completed.has(tc.id)) {
      continue;
    }
    const task = tasks[tc.taskKey] || tasks.simple || DEFAULT_TASKS.simple;
    // Persona precedence: test case personaKey/persona text > global selected persona
    const testPersona = tc.personaKey
      ? settings.personas?.[tc.personaKey]
      : (tc.persona ? { name: 'Custom Persona', description: tc.persona } : globalPersona);
    let result;
    try {
      const ren = await renarrateText(
        tc.content,
        tc.taskKey,
        task,
        { personaKey: tc.personaKey, personaText: tc.persona, modelId: tc.modelId }
      );
      result = ren;
    } catch (e) {
      result = { success: false, error: e.message };
    }
    const now = new Date();
    const iso = now.toISOString();
    const human = now.toLocaleString(undefined, {
      year: 'numeric', month: 'short', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
    const logEntry = await appendLog({
      testId: tc.id,
      timestampIso: iso,
      timestampHuman: human,
      modelId: tc.modelId,
      persona: tc.persona ?? testPersona?.name ?? testPersona?.description ?? '',
      taskKey: tc.taskKey,
      taskName: task.name,
      contentSample: tc.content.slice(0, 400),
      success: result.success,
      output: result.result || null,
      error: result.error || null,
      evaluation: "" // user fills later
    });
    allLogs.push(logEntry);
    completed.add(tc.id);
  }
  // Persist completed set for future runs
  await chrome.storage.local.set({ completedTestIds: Array.from(completed) });
  return { success: true, logs: allLogs };
}

// Update evaluation field
async function evaluateLog(testId, evaluation) {
  const existing = await chrome.storage.local.get(['testLogs']);
  const logs = existing.testLogs || [];
  const idx = logs.findIndex(l => l.testId === testId);
  if (idx >= 0) {
    logs[idx].evaluation = evaluation;
    await chrome.storage.local.set({ testLogs: logs });
    return { success: true };
  }
  return { success: false, error: 'Log not found' };
}

// Export logs as downloadable JSON
async function exportLogs() {
  const existing = await chrome.storage.local.get(['testLogs']);
  const logs = existing.testLogs || [];
  const dataUrl = 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
  await chrome.downloads.download({
    url: dataUrl,
    filename: `renarration-logs-${new Date().toISOString().slice(0,10)}.json`,
    saveAs: true
  });
  return { success: true };
}

// -----------------
// Screenshot capture
// -----------------

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function evalInTab(tabId, func, args = []) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func,
    args
  });
  return result;
}

async function getPageMetrics(tabId) {
  return await evalInTab(tabId, () => {
    const d = document;
    const body = d.body;
    const de = d.documentElement;
    const scrollHeight = Math.max(
      body ? body.scrollHeight : 0,
      de ? de.scrollHeight : 0
    );
    const clientHeight = window.innerHeight || (de && de.clientHeight) || 0;
    const dpr = window.devicePixelRatio || 1;
    const y = window.scrollY || window.pageYOffset || 0;
    return { scrollHeight, clientHeight, dpr, y };
  });
}

async function scrollToY(tabId, y) {
  await evalInTab(tabId, (yy) => {
    window.scrollTo(0, yy);
  }, [y]);
}

async function captureViewport(windowId, format = 'png', quality = 100) {
  // Quota-aware wrapper around captureVisibleTab.
  // Retries if hitting MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND.
  const MAX_RETRIES = 6;
  const BASE_DELAY = 900; // ms between retries
  let attempt = 0;
  while (true) {
    try {
      const dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format, quality });
      return dataUrl;
    } catch (e) {
      const msg = e?.message || String(e);
      if (/MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND/i.test(msg) && attempt < MAX_RETRIES) {
        const backoff = BASE_DELAY + attempt * 400; // linear backoff
        await new Promise(r => setTimeout(r, backoff));
        attempt++;
        continue;
      }
      throw e;
    }
  }
}

async function captureFullPageScreenshots(tabId) {
  try {
    const { images, meta, partial } = await captureFullPageSlices(tabId);
    // Debug: log screenshot sizes
    const totalSize = images.reduce((sum, img) => sum + (img.dataUrl?.length || 0), 0);
    console.log(`[captureFullPageScreenshots] ${images.length} slices, total size: ${(totalSize/1024/1024).toFixed(2)} MB`);
    
    // Persist slices for viewer
    try {
      await chrome.storage.local.set({
        lastScreenshots: images,
        lastScreenshotMeta: meta
      });
      console.log(`[captureFullPageScreenshots] Screenshots stored successfully`);
    } catch (e) {
      console.error(`[captureFullPageScreenshots] Storage failed:`, e.message);
      // Try storing without images - just metadata
      await chrome.storage.local.set({
        lastScreenshots: [],
        lastScreenshotMeta: { ...meta, error: 'Screenshots too large to store' }
      });
    }
    await chrome.tabs.create({ url: chrome.runtime.getURL('viewers/screenshot-viewer.html') });
    return { success: true, count: images.length, partial };
  } catch (e) {
    console.error(`[captureFullPageScreenshots] Error:`, e.message);
    return { success: false, error: e?.message || String(e) };
  }
}

async function captureFullPageSlices(tabId) {
  let tab = tabId ? await chrome.tabs.get(tabId) : await getActiveTab();
  if (!tab) throw new Error('No active tab found');
  try { await chrome.tabs.update(tab.id, { active: true }); } catch {}

  const startMetrics = await getPageMetrics(tab.id);
  let total = startMetrics.scrollHeight;
  const originalY = startMetrics.y || 0;

  const images = [];
  const maxSlices = 50; // hard cap to avoid excessive quota usage
  const settleDelayMs = 350; // wait after scroll before capture
  const sliceOverlapPx = 200; // small overlap to avoid missing boundary content
  let y = 0;
  let sliceIndex = 0;

  while (y < total && sliceIndex < maxSlices) {
    await scrollToY(tab.id, y);
    await new Promise(r => setTimeout(r, settleDelayMs));
    let dataUrl;
    try {
      dataUrl = await captureViewport(tab.windowId, 'png', 95);
    } catch (e) {
      if (/MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND/i.test(e?.message || '')) {
        break;
      }
      throw e;
    }
    images.push({ y, dataUrl });
    sliceIndex++;

    if (sliceIndex % 5 === 0) {
      const m = await getPageMetrics(tab.id);
      if (m.scrollHeight > total) total = m.scrollHeight;
    }

    const step = Math.max(1, startMetrics.clientHeight - sliceOverlapPx);
    y += step;
    if (y >= total - 1) break;
  }

  await scrollToY(tab.id, originalY);

  const partial = images.length < Math.ceil(total / Math.max(1, startMetrics.clientHeight));
  const meta = {
    overlapPx: sliceOverlapPx,
    clientHeight: startMetrics.clientHeight,
    dpr: startMetrics.dpr || 1
  };
  return { images, meta, partial };
}

async function stitchSlicesToDataUrl(slices, { maxWidth = null, maxHeight = null, format = 'image/png' } = {}) {
  if (!slices || !slices.length) return null;
  try {
    const first = slices[0];
    const { width, height } = await getImageDimensions(first.dataUrl);
    const totalHeight = slices.reduce((max, s) => Math.max(max, s.y + height), 0);
    const baseCanvas = new OffscreenCanvas(width, totalHeight);
    const ctx = baseCanvas.getContext('2d');
    for (const slice of slices) {
      const bmp = await dataUrlToBitmap(slice.dataUrl);
      ctx.drawImage(bmp, 0, slice.y);
      bmp.close && bmp.close();
    }

    let finalCanvas = baseCanvas;
    // Optional downscale to stay within size limits (if provided)
    if (typeof maxWidth === 'number' && typeof maxHeight === 'number') {
      const scale = Math.min(1, maxWidth / width, maxHeight / totalHeight);
      if (scale < 1) {
        const scaled = new OffscreenCanvas(Math.max(1, Math.round(width * scale)), Math.max(1, Math.round(totalHeight * scale)));
        const sctx = scaled.getContext('2d');
        sctx.drawImage(baseCanvas, 0, 0, scaled.width, scaled.height);
        finalCanvas = scaled;
      }
    }

    const blob = await finalCanvas.convertToBlob({ type: format, quality: format === 'image/jpeg' ? 0.9 : undefined });
    const dataUrl = await blobToDataUrl(blob);
    return dataUrl;
  } catch (e) {
    console.warn('Stitch failed, falling back to first slice:', e?.message || e);
    return slices[0].dataUrl || null;
  }
}

async function getImageDimensions(dataUrl) {
  const bmp = await dataUrlToBitmap(dataUrl);
  const dims = { width: bmp.width, height: bmp.height };
  bmp.close && bmp.close();
  return dims;
}

async function dataUrlToBitmap(dataUrl) {
  const res = await fetch(dataUrl);
  const blob = await res.blob();
  return await createImageBitmap(blob);
}

async function blobToDataUrl(blob) {
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
